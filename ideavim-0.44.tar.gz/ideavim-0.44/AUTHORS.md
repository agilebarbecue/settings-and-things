IdeaVim Authors
===============

The original author:

* [Rick Maddy](mailto:rmaddy@maddyhome.com)

The current maintainer:

* [Andrey Vlasovskikh](mailto:andrey.vlasovskikh@gmail.com)

Previous maintainers:

* [Oleg Shpynov](mailto:oleg.shpynov@jetbrains.com)

Contributors:

* [Dmitry Jemerov](mailto:yole@jetbrains.com)
* [Marquis Wang](mailto:marquis@marquiswang.com)
* [Julien Hoarau](mailto:madgnome@gmail.com)
* [Masanobu Imai](mailto:masanobu.imai@gmail.com)
* [poxu](mailto:poxvuibr@gmail.com)
* [Alexander Zolotov](mailto:alexander.zolotov@jetbrains.com)
* [John Lindquist](mailto:johnlindquist@gmail.com)
* [Ira Klotzko](mailto:iklotzko@ltech.com)
* [Alex Selesse](mailto:alex@selesse.com)
* [Dathan Bennett](mailto:dbennett@palantir.com)
* [salaam](mailto:kphayen@gmail.com)
* [Alexey Shmalko](mailto:rasen.dubi@gmail.com)
* [Andrew Brookins](mailto:a.m.brookins@gmail.com)
* [Chang Wang](mailto:changwang83@gmail.com)
* [Jaime Sanchez](mailto:josejaime.sanchez@gmail.com)
* [Thomas B Homburg](mailto:thomas@homburg.dk)
* [smartbomb](mailto:smartbomb@server.fake)
* [Tuomas Tynkkynen](mailto:tuomas.tynkkynen@iki.fi)
* [Jackson Popkin](mailto:jackson@donorschoose.org)

If you are a contributor and your name is not listed here, feel free to
contact the maintainer.
